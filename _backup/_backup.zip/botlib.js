const NODATA = 'NULL PORT DATA';
const WRITEMODE = {
	overwrite: 'w',
	append: 'a'
}

export const LOGLEVEL = {
	0: '',
	1: 'INFO',
	2: 'WARN',
	3: 'ERROR'
}

export const LOGTYPE = {
	process: 'process', // start/stop/running mundane
	info: 'info',
	notable: 'notable',
	error: 'error',
	excite: 'excite',
	wtf: 'wtf',
	event: 'event'
}

const config = {
	data: {
		network: {
			script: 'network-data.js',
			host: 'home'
		},
		player: {
			script: 'player-data.js',
			host: 'home'
		},
		targets: {
			script: 'targets-data.js',
			host: 'home'
		},
		settings: {
			script: 'settings-data.js',
			host: 'home'
		},
		stock: {
			script: 'stock-data.js',
			host: 'home'
		}
	}
}

export const getConfig = () => config;

export const getRandomInt = (max) => Math.floor(Math.random() * max)

export const roundTo = (places, value) => {
	return Math.round(value * Math.pow(10, places)) / Math.pow(10, places);
}

export const maxThreads = (scriptRam = 1, max, used, buffer = 0) => {
	const free = max - used - buffer;
	return Math.max(1, Math.floor(free / scriptRam));
}

export const localState = {
	settings: {
		loglevl: 1
	}
}

export const formats = fieldType => {
	const num = '0.000';
	const formattings = {
		coin: '$0.00a',
		num,
		percent: '0.00%',
	}
	return formattings[fieldType] || num;
}

/** @param {NS} ns **/
export const dataLibrary = ns => {

	const getSettings = async (field) => {
		const settings = await ns.read('settings.json.txt');
		const json = JSONSafeParse(settings);
		localState.settings = json;
		return field ? json[field] : json;
	}

	const updateSettings = (settings = {}) => {
		localState.settings = settings;
	}

	const JSONSafeParse = (jsonString, context) => {
		let results = null;
		if (typeof jsonString !== 'string') return {
			error: 'SafeParse expects a string'
		};
		try {
			results = JSON.parse(jsonString);
		} catch (err) {
			if (ns) {
				log(`JSONSafeParse with ${context} error: ${err}`, LOGTYPE.wtf, { 
					event: 'error', error: err, from: 'JSONSafeParse', message: `JSONSafeParse with ${context}` 
				});
			}
		}
		return results;
	}

	const getDataLog = (botname, host) => {
		const data = ns.getScriptLogs(botname, host);
		if (data) {
			return data[data.length - 1];
		}
		else {
			log(`${host}.${botname} may not be running`, LOGTYPE.process);
		}
		return null;
	}

	const getDataFor = async (dataType) => {
		if (!Object.keys(config.data).includes(dataType)) {
			// ns.tprint(`getDataFor: invalid datatype "${dataType}"`, LOGTYPE.error);
			return { error: 'invalid datatype' };
		}
		const { script, host } = config.data[dataType];
		const logData = getDataLog(script, host);
		if (logData) {
			await ns.write(`${dataType}.json.txt`, logData, 'w');
			return JSONSafeParse(logData, 'logData ' + dataType);
		}
		try {
			const cacheFile = await ns.read(`${dataType}.json.txt`);
			return JSONSafeParse(cacheFile, 'cacheFile');
		}
		catch (e) {
			log(`cachefileFailed: ${dataType}`, LOGTYPE.wtf);
		}
		return {}
	}

	const getNetworkData = async () => getDataFor('network');
	const getPlayerData = async () => getDataFor('player');
	const getTargetData = async () => getDataFor('targets');
	const getSettingsData = async () => getDataFor('settings');
	const getStockData = async () => getDataFor('stock');

	const logData = (data = {}) => {
		if (typeof statusData === 'object') {
			statusData.datetime = Date.now();
			ns.print(statusData);
		}
	}

	const log = (msg, logtype, statusData) => {
		let loglevel = 99; 

		const levels = [
			'ALL',
			['error', 'wtf', 'notable', 'excite']
		]

		const prefixMap = {
			process: 1,
			info: 1,
			notable: 2,
			error: 3,
			excite: 2,
			wtf: 3
		}
		const decoration = {
			process: ['--== ', ' ==--'],
			info: ['-[o] ', ' [o]-'],
			notable: ['[!== ', ' ==!]'],
			error: ['-!!! ', ' !!!-'],
			excite: ['~\\o/ ', ' \\o/~'],
			wtf: ['WTF! ', ' !FTW'],
		}
		const prefix = LOGLEVEL[prefixMap[logtype]];
		const ends = decoration[logtype] || ['', ''];
		const logmsg = `${prefix} ${ends[0]}${msg}${ends[1]}`;

		if (loglevel < 99) {
			if ((levels[loglevel] === 'ALL' || levels[loglevel]?.includes(logtype))) {
				ns.tprint(logmsg);
			}
		}
		if (typeof statusData === 'object') {
			statusData.datetime = Date.now();
			ns.print(statusData);
		}
	}

	const fcoin = (n = 0) => ns.nFormat(n, '$0.000a');
	const fnum = (n = 0) => ns.nFormat(n, '0.00');
	const fpercent = (n = 0) => ns.nFormat(n, '0.00%');

	return {
		log,
		logData,
		fcoin,
		fnum,
		fpercent,
		getNetworkData,
		getPlayerData,
		getTargetData,
		getSettingsData,
		getStockData,
		getDataFor,
		getDataLog,
		JSONSafeParse,
		getSettings,
		updateSettings,
		LOGTYPE
	}

}
