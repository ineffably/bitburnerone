import { dataLibrary, getRandomInt } from './botlib';

const sleepSeconds = 1;
const state = {
  pastTargets: []
}

const getChoice = (serverList) => {
  const selected = serverList[getRandomInt(serverList.length - 1)];
  state.pastTargets.push(selected);
  return selected;
}

const nextTarget = (hostNames = []) => {
  const available = hostNames.filter(hostname => !state.pastTargets.includes(hostname));
  if (available.length === 0) {
    state.pastTargets = [];
    return getChoice(hostNames);
  }
  return getChoice(available);
}

/** @param {NS} ns **/
export async function main(ns) {
  ns.disableLog('ALL');
  const { getTargetData, log, LOGTYPE, getPlayerData } = dataLibrary(ns);
  const args = ns.args;
  const runonce = args[0] === 'once';
  const { threads } = ns.getRunningScript()
  const fcoin = (n = 0) => ns.nFormat(n, '$0.00a');
  const fnum = (n = 0) => ns.nFormat(n, '0.000');
  const fper = (n = 0) => ns.nFormat(n, '0.00%');

  const getNextServer = async () => {
    const { servers, targets } = await getTargetData();
    if (targets.length > 0 && targets[0] !== '') {
      return servers[nextTarget(targets)];
    }
    return servers[nextTarget(Object.keys(servers))];
  }

  while (true) {
    const host = ns.getHostname();
    const target = await getNextServer();;
    const { hacking } = await getPlayerData();
    if (!target) {
      log(ns, `no hack targets`, LOGTYPE.notable);
      await ns.sleep(getRandomInt(1000 * sleepSeconds))
      continue;
    }
    if (target.moneyMax === 0) {
      await ns.sleep(500);
      continue;
    }

    
    const {
      hackTime,
      hackChance,
      hostname,
      baseDifficulty,
      hackDifficulty,
      moneyAvailable,
      serverGrowth,
      minDifficulty,
      moneyMax,
      action
    } = target;

      const percentLeft = moneyAvailable / moneyMax;
      let hackResults = 0;
      // log(`hack evaluating ${hostname}: chance: ${hackChance}|${hacking}|${hackDifficulty}|${fcoin(percentLeft)}|${fcoin(moneyAvailable)}`, LOGTYPE.process);

      if (action === 'hack') {
        log(`${hostname} from ${host} with ${hackChance} chance taking ${Math.floor(hackTime) / 1000} seconds`, LOGTYPE.process, { event: 'hackAttempt', hostname, hackChance, hackTime, moneyAvailable, hackDifficulty, hacking });
        hackResults = await ns.hack(hostname, { threads });
        log(`hack ${fcoin(hackResults)} ${host}=>${hostname} given ${fper(hackChance)} chance`, LOGTYPE.excite, { event: 'hack', hostname, hackResults });
        const stats = `${fper(percentLeft)} left:(${fcoin(moneyAvailable - hackResults)} / ${fcoin(moneyMax)}) `;
        log( stats + `growth:${serverGrowth} dif:base:${baseDifficulty} min:${fnum(minDifficulty)} hack:${fnum(hackDifficulty)}`, LOGTYPE.notable);
      }
      else if(action === 'grow'){
        log( `growing ${hostname} from ${host}`, LOGTYPE.process, { event: 'growAttempt', hostname, serverGrowth, moneyAvailable });
        const growResults = await ns.grow(hostname, { threads });
        log( `grow ${hostname}  for ${fnum(growResults)} units on ${host}`, LOGTYPE.notable, { event: 'grow', hostname, growResults });
      }
      else if(action === 'weaken'){
          log(`weakening ${hostname} from ${host}`, LOGTYPE.process, { event: 'weakAttempt', hostname, minDifficulty, hackDifficulty, hacking });
          const weakenResults = await ns.weaken(hostname, { threads });
          log(`weaken ${hostname} for ${fnum(weakenResults)} units on ${host}`, LOGTYPE.notable, { event: 'weaken', hostname, weakenResults });
      }
    if (runonce) {
      break;
    }
    await ns.sleep(getRandomInt(1000 * sleepSeconds));
  }
}
