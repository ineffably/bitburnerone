import { dataLibrary } from './botlib';

// q servers [field][op][criteria] fieldnames,, 
// q servers fields              // all field names
// q servers fields fieldnames,, // specific fields
// q servers hostname
// q servers hostname field
// q servers 
// q player
// q player field
// q settings 
// q settings fields
// q targets [field][op][criteria] fieldnames,,
// q targets "fields"
// q targets hostname
// q targets hostname field

const dbnames = [
    'servers',
    'player',
    'targets',
    'settings'
]
const usage = [
    'q servers [field][op][criteria] fieldnames,',
    'q servers "showfields"',
    'q servers hostname',
    'q servers hostname field',
    'q player',
    'q player field'
]
const opTable = {
    'eq': ' == ',
    'ne': ' != ',
    'ge': ' >= ',
    'le': ' <= ',
    'gt': ' > ',
    'lt': ' < ',
    'mod': ' % '
}

const filter2Common = [
    'showfields',
    'fields',
    '[field][op][criteria]'
]


export function autocomplete(data, args) {
    const database = args[0];
    const filter1 = args[1];
    if (filter1) {
        return [...filter2Common, ...(getFields(database) || [])];
    }
    if (database) return dbnames;
}

const stringify = obj => JSON.stringify(obj, null, 2);

/** @param {NS} ns **/
export async function main(ns) {
    const { getNetworkData, getPlayerData, getTargetData } = dataLibrary(ns);
    const { args } = ns;
    const db = args[0];
    const filter1 = args[1];
    const filter2 = args[2];
    const isQuery = filter1 && filter1.startsWith('[');

    const getAllData = async () => {
        const { servers, network } = await getNetworkData();
        return {
            servers,
            network,
            player: await getPlayerData(),
            targets: await getTargetData()
        }
    }

    if (!db && !filter1 && !filter2) {
        return ns.tprint('\n' + usage.join('\n'));
    }
    if (!dbnames.includes(db)) {
        return ns.tprint(`${db} data not found`);
    }

    const allData = await getAllData();
    const { player, targets, servers } = allData;

    if (isQuery) {
        return queryDb(ns, Object.values(allData[db]), filter1, filter2);
    }

    if (filter1) {
        const data = allData[db];
        const targetData = db === 'player' ? data : Object.values(data);
        const fields = filter1.split(',');
        if (Array.isArray(targetData)) {
            const output = targetData.reduce((origin, entry) => {
                const { hostname } = entry;
                const outputEntry = origin[hostname] || {};
                fields.forEach(field => (outputEntry[field] = entry[field]));
                origin[hostname] = outputEntry;
                return origin;
            }, {});
            return ns.tprint(stringify(output));
        }
        else {
            const outputEntry = {};
            fields.forEach(field => (outputEntry[field] = targetData[field]));
            return ns.tprint(stringify(outputEntry));
        }
    }

    if (db === 'player') {
        return ns.tprint(stringify(player));
    }

    if (db === 'targets') {
        return ns.tprint(stringify(targets));
    }

    if (db === 'servers') {
        return renderTable(ns, Object.values(servers).map(server => server));
    }
}

function queryDb(ns, dataList, filter1, filter2) {
    const partNames = ['field', 'op', 'value']
    const userFilter = filter1.split(']').slice(0, 3);

    const criterion = userFilter.reduce((origin, entry, i) => {
        const part = i % 3;
        if ((part === 0 || part === 1) && !partNames[part]) {
            return;
        }
        origin[partNames[part]] = entry.substr(1);
        return origin;
    }, {});

    const getResults = () => {
        const { field, op, value = '' } = criterion;
        const operator = opTable[op];
        if (!operator) return;
        const results = dataList.filter(entry => {
            const fieldData = entry[field];
            if (op === 'eq') return fieldData == value;
            if (op === 'gt') return fieldData > value;
            if (op === 'lt') return fieldData < value;
            if (op === 'le') return fieldData <= value;
            if (op === 'gt') return fieldData > value;
            if (op === 'ge') return fieldData >= value;
            if (op === 'mod') return fieldData % value;
        })
        return results;
    }
    const results = getResults();

    ns.tprint(stringify(results));
}

function getFields(dbname) {
    const fieldData = {
        servers: [
            "cpuCores",
            "ftpPortOpen",
            "hasAdminRights",
            "hostname",
            "httpPortOpen",
            "ip",
            "isConnectedTo",
            "maxRam",
            "organizationName",
            "ramUsed",
            "smtpPortOpen",
            "sqlPortOpen",
            "sshPortOpen",
            "purchasedByPlayer",
            "backdoorInstalled",
            "baseDifficulty",
            "hackDifficulty",
            "minDifficulty",
            "moneyAvailable",
            "moneyMax",
            "numOpenPortsRequired",
            "openPortCount",
            "requiredHackingSkill",
            "serverGrowth",
            "network"
        ],
        player: [
            "hacking",
            "hp",
            "max_hp",
            "strength",
            "defense",
            "dexterity",
            "agility",
            "charisma",
            "intelligence",
            "hacking_chance_mult",
            "hacking_speed_mult",
            "hacking_money_mult",
            "hacking_grow_mult",
            "hacking_exp",
            "strength_exp",
            "defense_exp",
            "dexterity_exp",
            "agility_exp",
            "charisma_exp",
            "hacking_mult",
            "strength_mult",
            "defense_mult",
            "dexterity_mult",
            "agility_mult",
            "charisma_mult",
            "hacking_exp_mult",
            "strength_exp_mult",
            "defense_exp_mult",
            "dexterity_exp_mult",
            "agility_exp_mult",
            "charisma_exp_mult",
            "company_rep_mult",
            "faction_rep_mult",
            "numPeopleKilled",
            "money",
            "city",
            "location",
            "companyName",
            "crime_money_mult",
            "crime_success_mult",
            "isWorking",
            "workType",
            "currentWorkFactionName",
            "currentWorkFactionDescription",
            "workHackExpGainRate",
            "workStrExpGainRate",
            "workDefExpGainRate",
            "workDexExpGainRate",
            "workAgiExpGainRate",
            "workChaExpGainRate",
            "workRepGainRate",
            "workMoneyGainRate",
            "workMoneyLossRate",
            "workHackExpGained",
            "workStrExpGained",
            "workDefExpGained",
            "workDexExpGained",
            "workAgiExpGained",
            "workChaExpGained",
            "workRepGained",
            "workMoneyGained",
            "createProgramName",
            "createProgramReqLvl",
            "className",
            "crimeType",
            "work_money_mult",
            "hacknet_node_money_mult",
            "hacknet_node_purchase_cost_mult",
            "hacknet_node_ram_cost_mult",
            "hacknet_node_core_cost_mult",
            "hacknet_node_level_cost_mult",
            "hasWseAccount",
            "hasTixApiAccess",
            "has4SData",
            "has4SDataTixApi",
            "bladeburner_max_stamina_mult",
            "bladeburner_stamina_gain_mult",
            "bladeburner_analysis_mult",
            "bladeburner_success_chance_mult",
            "bitNodeN",
            "totalPlaytime",
            "playtimeSinceLastAug",
            "playtimeSinceLastBitnode",
            "jobs",
            "factions",
            "tor",
            "hasCorporation"
        ],
        targets: [
            "cpuCores",
            "ftpPortOpen",
            "hasAdminRights",
            "hostname",
            "httpPortOpen",
            "ip",
            "isConnectedTo",
            "maxRam",
            "organizationName",
            "ramUsed",
            "smtpPortOpen",
            "sqlPortOpen",
            "sshPortOpen",
            "purchasedByPlayer",
            "backdoorInstalled",
            "baseDifficulty",
            "hackDifficulty",
            "minDifficulty",
            "moneyAvailable",
            "moneyMax",
            "numOpenPortsRequired",
            "openPortCount",
            "requiredHackingSkill",
            "serverGrowth",
            "network",
            "moneyGap",
            "shouldGrow",
            "shouldWeaken",
            "peekMoney",
            "hackChance",
            "hackThreads",
            "weakenTime",
            "growTime",
            "hackTime"
        ]
    }
    return fieldData[dbname];
}

function renderTable(ns, dataList = [], header = 'hostname') {
    const fields = Object.keys(dataList[0]);
    const headerValues = [];
    const fieldData = fields.reduce((origin, entry) => {
        origin[entry] = { length: entry.length };
        return origin;
    }, {});
    const rows = fields.map(field => {
        const row = [field].concat(dataList.map(data => {
            if (headerValues.length < dataList.length) {
                headerValues.push(data[header]);
            }
            return data[field];
        }))
        return row;
    });

    const output = ['', headerValues.join(' | ')];
    rows.slice(0, 1).forEach(value => {
        output.push(value.join(' | '));
    })
    ns.tprint(output.join('\n'));
}
