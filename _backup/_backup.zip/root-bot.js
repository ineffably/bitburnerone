/** @param {NS} ns **/
import { dataLibrary } from './botlib';

export async function main(ns) {
  const { args } = ns;
  const { getNetworkData, log, LOGTYPE } = dataLibrary(ns);
  const runonce = args[0] === 'once';
  const config = {
    sleeptime: 1000 * 90
  }
  while (true) {
    const { servers = [] } = await getNetworkData();
    const serverList = Object.values(servers).filter(server => !server.hasAdminRights);
    log(`root-bot found ${serverList.length} candidates`, LOGTYPE.process);
    serverList.forEach(server => {
      const {
        hostname,
        numOpenPortsRequired,
        openPortCount,
        ftpPortOpen,
        httpPortOpen,
        smtpPortOpen,
        sqlPortOpen,
        sshPortOpen
      } = server;
      if (openPortCount >= numOpenPortsRequired) {
        try {
          log(`nuking ${hostname}`, LOGTYPE.process);
          const nukeResults = ns.nuke(hostname);
          if(nukeResults){
            log(`${hostname} OWNED`, LOGTYPE.excite, { event: 'nuked', hostname });
          }
        }
        catch (e) {
          log(`nuke fail ${e}`, LOGTYPE.wtf);
        }
      }
      else {
        if (!sshPortOpen) {
          try {
            if(ns.brutessh(hostname)){
              log(`${hostname} ssh port opened`, LOGTYPE.excite, { event: 'brutessh', hostname });
            }
          } catch (error) {}
        }
        if (!ftpPortOpen) {
          try {
            if(ns.ftpcrack(host)) {
              log(`${hostname} ftp port opened`, LOGTYPE.excite, { event: 'ftpcrack', hostname });
            }
          } catch (error) { }
        }
        if (!smtpPortOpen) {
          try {
            if(ns.relaysmtp(hostname)) {
              log(`${hostname} smtp port opened`, LOGTYPE.excite, { event: 'relaysmtp', hostname });
            }
          } catch (error) { }
        }
        if (!httpPortOpen) {
          try {
            if(ns.httpworm(hostname)) {
              log(`${hostname} http port opened`, LOGTYPE.excite, { event: 'httpworm', hostname });
            }
          } catch (error) { }
        }
        if (!sqlPortOpen) {
          try {
            if(ns.sqlinject(hostname)) {
              log(`${hostname} sql port opened`, LOGTYPE.excite, { event: 'sqlinject', hostname });
            }
          } catch (error) { }
        }
      }
    })
    if(runonce){ 
      break;
    }
    await ns.sleep(config.sleeptime);
  }

}
