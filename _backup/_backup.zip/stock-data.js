/** @param {NS} ns **/
export async function main(ns) {
  while (true) {
      const { stock } = ns;
      const {
          getSymbols,
          getForecast,
          getMaxShares,
          getAskPrice,
          getBidPrice,
          getPrice,
          getPosition,
          getVolatility
      } = stock;
      const symbols = getSymbols()
      const stockGrid = symbols.map(sym => {
          const results = {
              forcast: getForecast(sym),
              maxShares: getMaxShares(sym),
              askPrice: getAskPrice(sym),
              bigPrice: getBidPrice(sym),
              price: getPrice(sym),
              position: getPosition(sym),
              volatility: getVolatility(sym)
          }
          return results;
      })

      ns.clearLog();
      ns.print(JSON.stringify({ stockGrid }));
      await ns.sleep(1000);
  }
}
